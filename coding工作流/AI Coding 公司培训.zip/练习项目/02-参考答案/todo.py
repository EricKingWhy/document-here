"""本地待办清单练习。"""

import argparse
import json
import sys
from pathlib import Path
from tempfile import NamedTemporaryFile


def load_tasks(path):
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


def save_tasks(path, tasks):
    # ponytail: 练习中使用一个进程顺序写入。并发写入时应换用事务存储。
    with NamedTemporaryFile(dir=path.parent, delete=False) as temporary:
        draft = Path(temporary.name)
    try:
        draft.write_text(
            json.dumps(tasks, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        draft.replace(path)
    finally:
        draft.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description="本地待办清单")
    parser.add_argument("--file", type=Path, required=True, help="练习用 JSON 文件")
    commands = parser.add_subparsers(dest="command", required=True)
    add = commands.add_parser("add", help="新增任务")
    add.add_argument("text", help="任务内容")
    commands.add_parser("list", help="列出任务")
    done = commands.add_parser("done", help="完成任务")
    done.add_argument("id", type=int, help="任务编号")
    args = parser.parse_args()

    tasks = load_tasks(args.file)
    if args.command == "add":
        if not args.text.strip():
            parser.error("任务内容不能为空")
        task_id = max((task["id"] for task in tasks), default=0) + 1
        tasks.append({"id": task_id, "text": args.text, "done": False})
        save_tasks(args.file, tasks)
        print(f"已添加任务 {task_id}")
    elif args.command == "done":
        for task in tasks:
            if task["id"] == args.id:
                if not task.get("done", False):
                    task["done"] = True
                    save_tasks(args.file, tasks)
                print(f"已完成任务 {args.id}")
                return 0
        print(f"找不到任务 {args.id}", file=sys.stderr)
        return 1
    elif tasks:
        for task in tasks:
            marker = "x" if task.get("done", False) else " "
            print(f'{task["id"]}. [{marker}] {task["text"]}')
    else:
        print("暂无任务")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
