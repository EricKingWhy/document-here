"""通过真实命令行检查输出、退出码和数据保存。"""

from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest


SCRIPT = Path(__file__).with_name("todo.py").resolve()


class TodoCliTests(unittest.TestCase):
    def setUp(self):
        workspace = TemporaryDirectory()
        self.addCleanup(workspace.cleanup)
        self.data_file = Path(workspace.name) / "data.json"

    def run_cli(self, *args):
        return subprocess.run(
            [sys.executable, "-X", "utf8", str(SCRIPT), "--file", str(self.data_file), *args],
            capture_output=True,
            encoding="utf-8",
            check=False,
        )

    def test_empty_list(self):
        result = self.run_cli("list")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), "暂无任务")

    def test_add_and_list_keep_ids(self):
        self.assertEqual(self.run_cli("add", "买牛奶").stdout.strip(), "已添加任务 1")
        self.assertEqual(self.run_cli("add", "交作业").stdout.strip(), "已添加任务 2")
        result = self.run_cli("list")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.splitlines(), ["1. [ ] 买牛奶", "2. [ ] 交作业"])

    def test_reads_existing_data(self):
        self.data_file.write_text('[{"id": 7, "text": "旧任务"}]', encoding="utf-8")
        result = self.run_cli("list")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), "7. [ ] 旧任务")

    def test_done_persists_after_reload(self):
        self.run_cli("add", "买牛奶")
        self.run_cli("add", "交作业")
        finished = self.run_cli("done", "1")
        self.assertEqual(finished.returncode, 0, finished.stderr)
        self.assertEqual(finished.stdout.strip(), "已完成任务 1")
        result = self.run_cli("list")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.splitlines(), ["1. [x] 买牛奶", "2. [ ] 交作业"])

    def test_repeating_done_keeps_existing_file(self):
        self.data_file.write_text('[{"id": 7, "text": "旧任务"}]', encoding="utf-8")
        first = self.run_cli("done", "7")
        self.assertEqual(first.returncode, 0, first.stderr)
        saved = self.data_file.read_bytes()
        repeated = self.run_cli("done", "7")
        self.assertEqual(repeated.returncode, 0, repeated.stderr)
        self.assertEqual(repeated.stdout.strip(), "已完成任务 7")
        self.assertEqual(self.data_file.read_bytes(), saved)
        result = self.run_cli("list")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), "7. [x] 旧任务")

    def test_unknown_id_leaves_data_untouched(self):
        self.run_cli("add", "买牛奶")
        saved = self.data_file.read_bytes()
        result = self.run_cli("done", "99")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stderr.strip(), "找不到任务 99")
        self.assertEqual(self.data_file.read_bytes(), saved)


if __name__ == "__main__":
    unittest.main()
