# 练习需求来源

本地 Markdown 是训练项目的工单。待办完成需求在 `docs/feature-done.md`。审查时直接读取这个文件并引用验收项。

本练习的工单和 Git 提交均在本地。
