# 任务管理 API（教学版）
Python 3.11 + FastAPI + Pydantic v2。命令在此目录运行：

```bash
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

浏览器访问 http://127.0.0.1:8000/docs 。另开终端进入本目录，运行 `python -m pytest -q`。

内存存储仅教学：重启丢失，多进程不共享。未实现真实权限、数据库、状态流转规则或 Agent 调用。/diagnose 是模拟 I/O 并发。
