from fastapi.testclient import TestClient
from app.main import app
from app.routes import get_service
from app.service import TaskService


def test_task_lifecycle():
    svc = TaskService()
    app.dependency_overrides[get_service] = lambda: svc
    try:
        with TestClient(app) as client:
            assert client.get('/health').status_code == 200
            r = client.post('/tasks', json={'title': '检查 Agent', 'priority': 1})
            assert r.status_code == 201
            task_id = r.json()['id']
            assert client.get(f'/tasks/{task_id}').json()['status'] == 'pending'
            assert client.post('/tasks', json={'title': '', 'priority': 4}).status_code == 422
            r = client.patch(f'/tasks/{task_id}', json={'status': 'done'})
            assert r.status_code == 200
            assert r.json()['status'] == 'done'
            assert len(client.get('/tasks?status=done').json()) == 1
            assert client.delete(f'/tasks/{task_id}').status_code == 204
            assert client.get(f'/tasks/{task_id}').status_code == 404
            assert len(client.get('/diagnose').json()['components']) == 2
    finally:
        app.dependency_overrides.clear()
