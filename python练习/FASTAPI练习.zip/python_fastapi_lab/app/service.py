from threading import Lock
from .schemas import TaskCreate, TaskOut, Status

class TaskService:
    def __init__(self):
        self._tasks: dict[int, TaskOut] = {}
        self._next_id = 1
        self._lock = Lock()

    def create(self, data: TaskCreate) -> TaskOut:
        with self._lock:
            task = TaskOut(id=self._next_id, **data.model_dump())
            self._tasks[task.id] = task
            self._next_id += 1
            return task

    def get(self, task_id: int) -> TaskOut | None:
        with self._lock:
            return self._tasks.get(task_id)

    def list(self, status: Status | None = None) -> list[TaskOut]:
        with self._lock:
            return [t for t in self._tasks.values()
                    if status is None or t.status == status]

    def update(self, task_id: int, status: Status) -> TaskOut | None:
        with self._lock:
            task = self._tasks.get(task_id)
            if task is None:
                return None
            updated = task.model_copy(update={'status': status})
            self._tasks[task_id] = updated
            return updated

    def delete(self, task_id: int) -> bool:
        with self._lock:
            return self._tasks.pop(task_id, None) is not None
