from typing import Literal
from pydantic import BaseModel, Field

Status = Literal['pending', 'running', 'done', 'failed']

class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=100)
    priority: int = Field(default=2, ge=1, le=3)

class TaskUpdate(BaseModel):
    status: Status

class TaskOut(TaskCreate):
    id: int
    status: Status = 'pending'
