import asyncio
import logging
from time import perf_counter
from fastapi import FastAPI, Request
from .routes import router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
app = FastAPI(title='任务管理 API')
app.include_router(router)

@app.get('/health')
def health():
    return {'status': 'ok'}

@app.middleware('http')
async def log_request(request: Request, call_next):
    start = perf_counter()
    try:
        response = await call_next(request)
    except Exception:
        logger.exception('request failed: %s %s', request.method, request.url.path)
        raise
    logger.info('%s %s %s %.1fms', request.method, request.url.path,
                response.status_code, (perf_counter() - start) * 1000)
    return response

async def check_component(name: str, delay: float):
    await asyncio.sleep(delay)
    return {'name': name, 'status': 'ok'}

@app.get('/diagnose')
async def diagnose():
    # 模拟两个互不依赖的外部 I/O，不是真实监控检查
    results = await asyncio.gather(
        check_component('database', 0.2),
        check_component('agent', 0.3),
    )
    return {'components': results}
