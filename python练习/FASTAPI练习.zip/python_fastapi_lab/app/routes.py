from fastapi import APIRouter, Depends, HTTPException, Response
from .schemas import TaskCreate, TaskUpdate, TaskOut, Status
from .service import TaskService

router = APIRouter(prefix='/tasks', tags=['tasks'])
service = TaskService()

def get_service() -> TaskService:
    return service

@router.post('', response_model=TaskOut, status_code=201)
def create_task(data: TaskCreate, svc: TaskService = Depends(get_service)):
    return svc.create(data)

@router.get('', response_model=list[TaskOut])
def list_tasks(status: Status | None = None,
               svc: TaskService = Depends(get_service)):
    return svc.list(status)

@router.get('/{task_id}', response_model=TaskOut)
def get_task(task_id: int, svc: TaskService = Depends(get_service)):
    task = svc.get(task_id)
    if task is None:
        raise HTTPException(404, '任务不存在')
    return task

@router.patch('/{task_id}', response_model=TaskOut)
def update_task(task_id: int, data: TaskUpdate,
                svc: TaskService = Depends(get_service)):
    task = svc.update(task_id, data.status)
    if task is None:
        raise HTTPException(404, '任务不存在')
    return task

@router.delete('/{task_id}', status_code=204, response_class=Response)
def delete_task(task_id: int, svc: TaskService = Depends(get_service)):
    if not svc.delete(task_id):
        raise HTTPException(404, '任务不存在')
    return Response(status_code=204)
