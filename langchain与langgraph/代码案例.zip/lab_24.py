from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.config import get_stream_writer

class State(TypedDict):
    report: str

def search(state: State):
    writer = get_stream_writer()
    writer({"stage": "search", "percent": 20})
    writer({"stage": "search", "percent": 80})
    return {"report": "完成"}

b = StateGraph(State)
b.add_node("search", search)
b.add_edge(START, "search")
b.add_edge("search", END)
g = b.compile()
for mode, chunk in g.stream({}, stream_mode=["custom", "updates"]):
    print(mode, chunk)
