from typing import TypedDict, Annotated, Literal
import operator
from langgraph.graph import StateGraph, START, END

class Research(TypedDict):
    question: str
    rounds: int
    evidence: Annotated[list[str], operator.add]
    report: str

def plan(s: Research):
    return {"rounds": 0}
def search(s: Research):
    round_no = s["rounds"] + 1
    # 教学模拟；真实实现需要检索来源、去重和来源可靠性核验
    evidence = ["模拟来源：监控数据"] if round_no == 1 else ["模拟来源：发布记录"]
    return {"rounds": round_no, "evidence": evidence}
def review(s: Research):
    return {}
def next_step(s: Research) -> Literal["again", "done"]:
    enough = len(set(s["evidence"])) >= 2
    return "done" if enough or s["rounds"] >= 3 else "again"
def report(s: Research):
    status = "证据达到演示阈值" if len(set(s["evidence"])) >= 2 else "证据不足"
    return {"report": status + "：" + "；".join(s["evidence"])}

b = StateGraph(Research)
for name, fn in [("plan", plan), ("search", search), ("review", review), ("report", report)]:
    b.add_node(name, fn)
b.add_edge(START, "plan")
b.add_edge("plan", "search")
b.add_edge("search", "review")
b.add_conditional_edges("review", next_step, {"again": "search", "done": "report"})
b.add_edge("report", END)
g = b.compile()
r = g.invoke({"question": "订单服务异常原因", "evidence": []}, config={"recursion_limit": 20})
assert r["rounds"] == 2
print(r["report"])
