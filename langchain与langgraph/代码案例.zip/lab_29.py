import operator
from typing import TypedDict, Annotated, Literal
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import interrupt, Command

class Incident(TypedDict):
    incident_id: str
    service: str
    cpu: int
    evidence: Annotated[list[str], operator.add]
    proposal: str
    decision: str

def classify(s: Incident):
    return {}
def route(s: Incident) -> Literal["high", "low"]:
    return "high" if s["cpu"] >= 90 else "low"
def fanout(s: Incident):
    return {}
def metrics(s: Incident):
    return {"evidence": [f"CPU {s['cpu']}%"]}
def logs(s: Incident):
    return {"evidence": ["模拟日志：upstream timeout"]}
def summarize(s: Incident):
    return {"proposal": "证据：" + "；".join(sorted(s["evidence"])) + "。建议人工检查上游。"}
def review(s: Incident):
    approved = interrupt({"incident_id": s["incident_id"], "proposal": s["proposal"]})
    return {"decision": "approved_for_manual_review" if approved is True else "rejected"}
def close(s: Incident):
    return {"decision": "monitor_only"}

b = StateGraph(Incident)
for name, fn in [("classify", classify), ("fanout", fanout), ("metrics", metrics),
                 ("logs", logs), ("summarize", summarize), ("review", review), ("close", close)]:
    b.add_node(name, fn)
b.add_edge(START, "classify")
b.add_conditional_edges("classify", route, {"high": "fanout", "low": "close"})
b.add_edge("fanout", "metrics")
b.add_edge("fanout", "logs")
b.add_edge(["metrics", "logs"], "summarize")
b.add_edge("summarize", "review")
b.add_edge("review", END)
b.add_edge("close", END)
graph = b.compile(checkpointer=InMemorySaver())

def run_demo():
    cfg = {"configurable": {"thread_id": "inc-001"}}
    initial = {"incident_id": "inc-001", "service": "order-api", "cpu": 95, "evidence": []}
    paused = graph.invoke(initial, cfg)
    assert "__interrupt__" in paused
    print(paused["proposal"])
    final = graph.invoke(Command(resume=True), cfg)
    assert final["decision"] == "approved_for_manual_review"
    print(final["decision"])
    low = graph.invoke({**initial, "incident_id": "inc-002", "cpu": 30},
                       {"configurable": {"thread_id": "inc-002"}})
    assert low["decision"] == "monitor_only"
    print(low["decision"])

if __name__ == "__main__":
    run_demo()
