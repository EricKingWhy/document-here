import operator
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END

class State(TypedDict):
    evidence: Annotated[list[str], operator.add]
    report: str

def metrics(state: State):
    return {"evidence": ["CPU 95%"]}
def logs(state: State):
    return {"evidence": ["线程池满"]}
def report(state: State):
    return {"report": "；".join(sorted(state["evidence"]))}

b = StateGraph(State)
for name, fn in [("metrics", metrics), ("logs", logs), ("report", report)]:
    b.add_node(name, fn)
b.add_edge(START, "metrics")
b.add_edge(START, "logs")
b.add_edge(["metrics", "logs"], "report")
b.add_edge("report", END)
print(b.compile().invoke({"evidence": []}))
