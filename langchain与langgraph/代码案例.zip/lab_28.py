import logging
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("oncall")

class State(TypedDict):
    cpu: int
    severity: str

def classify(s: State):
    result = "high" if s["cpu"] >= 90 else "low"
    logger.info("node=classify severity=%s", result)
    return {"severity": result}

b = StateGraph(State)
b.add_node("classify", classify)
b.add_edge(START, "classify")
b.add_edge("classify", END)
g = b.compile()
assert classify({"cpu": 90}) == {"severity": "high"}
assert g.invoke({"cpu": 89})["severity"] == "low"
assert g.invoke({"cpu": 95})["severity"] == "high"
print("3 assertions passed")
