from langchain_core.messages import HumanMessage, AIMessage
from langgraph.graph import MessagesState, StateGraph, START, END

def reply(state: MessagesState):
    return {"messages": [AIMessage(content="收到告警", id="a1")]}

def revise(state: MessagesState):
    return {"messages": [AIMessage(content="已记录告警，请继续提供日志", id="a1")]}

b = StateGraph(MessagesState)
b.add_node("reply", reply)
b.add_node("revise", revise)
b.add_edge(START, "reply")
b.add_edge("reply", "revise")
b.add_edge("revise", END)
r = b.compile().invoke({"messages": [HumanMessage(content="CPU 高", id="u1")]})
for m in r["messages"]:
    print(m.id, m.content)
