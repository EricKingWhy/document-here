import json, os
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.tools import tool

@tool
def get_cpu(service: str) -> int:
    """查询服务 CPU 百分比（模拟）。"""
    return {"order-api": 95}.get(service, -1)

model = ChatOpenAI(model=os.environ["LLM_MODEL"], timeout=30).bind_tools([get_cpu])
messages = [HumanMessage(content="查询 order-api CPU")]
reply = model.invoke(messages)
messages.append(reply)
for call in reply.tool_calls:
    if call["name"] == get_cpu.name:
        value = get_cpu.invoke(call["args"])
    else:
        value = {"error": "tool not allowed"}
    messages.append(ToolMessage(content=json.dumps(value), tool_call_id=call["id"]))
if reply.tool_calls:
    reply = model.invoke(messages)
print(reply.content, reply.tool_calls)
