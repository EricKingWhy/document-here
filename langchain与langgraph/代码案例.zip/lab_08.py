import os
from langchain.agents import create_agent
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

@tool
def get_status(service: str) -> str:
    """读取服务状态（模拟），支持 order-api。"""
    return "order-api CPU 95%" if service == "order-api" else "无数据"

agent = create_agent(
    model=ChatOpenAI(model=os.environ["LLM_MODEL"], timeout=30),
    tools=[get_status], system_prompt="先查询证据，再回答，不要编造数据。"
)
result = agent.invoke({"messages": [{"role": "user", "content": "order-api 正常吗？"}]},
                      config={"recursion_limit": 12})
for message in result["messages"]:
    print(message.type, message.content)
