import json, asyncio
from typing import TypedDict
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from langgraph.graph import StateGraph, START, END

class State(TypedDict):
    service: str
    result: str
async def diagnose(s: State):
    await asyncio.sleep(0.2)
    return {"result": s["service"] + ": simulated CPU high"}
b = StateGraph(State)
b.add_node("diagnose", diagnose)
b.add_edge(START, "diagnose")
b.add_edge("diagnose", END)
graph = b.compile()
app = FastAPI()
class Request(BaseModel):
    service: str

@app.post("/diagnose/stream")
async def stream(req: Request):
    async def events():
        try:
            async for update in graph.astream({"service": req.service}, stream_mode="updates"):
                yield "data: " + json.dumps(update, ensure_ascii=False) + "\n\n"
            yield "event: done\ndata: {}\n\n"
        except Exception:
            yield 'event: error\ndata: {"message":"diagnosis failed"}\n\n'
    return StreamingResponse(events(), media_type="text/event-stream")
