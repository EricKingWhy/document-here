from typing import TypedDict, Literal
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command

class State(TypedDict):
    cpu: int
    severity: str
    result: str

def classify(state: State) -> Command[Literal["notify", "finish"]]:
    high = state["cpu"] >= 90
    return Command(update={"severity": "high" if high else "low"},
                   goto="notify" if high else "finish")
def notify(state: State):
    return {"result": "生成通知草稿（未发送）"}
def finish(state: State):
    return {"result": "结束"}

b = StateGraph(State)
b.add_node("classify", classify)
b.add_node("notify", notify)
b.add_node("finish", finish)
b.add_edge(START, "classify")
b.add_edge("notify", END)
b.add_edge("finish", END)
print(b.compile().invoke({"cpu": 95}))
