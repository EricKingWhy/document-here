from langgraph.store.memory import InMemoryStore

store = InMemoryStore()
namespace = ("tenant-demo", "user-001", "preferences")
store.put(namespace, "language", {"locale": "zh-CN"})
item = store.get(namespace, "language")
print(item.value if item else None)
print(store.get(("tenant-demo", "user-002", "preferences"), "language"))
