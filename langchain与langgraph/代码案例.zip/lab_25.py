import asyncio
from typing import TypedDict
from langgraph.graph import StateGraph, START, END

class State(TypedDict):
    evidence: list[str]
async def cpu():
    await asyncio.sleep(0.1)
    return "CPU 95%"
async def logs():
    await asyncio.sleep(0.2)
    return "upstream timeout"
async def collect(state: State):
    data = await asyncio.wait_for(asyncio.gather(cpu(), logs()), timeout=1)
    return {"evidence": data}

b = StateGraph(State)
b.add_node("collect", collect)
b.add_edge(START, "collect")
b.add_edge("collect", END)
g = b.compile()

async def main():
    print(await g.ainvoke({}))
asyncio.run(main())
