from typing import TypedDict
from langgraph.graph import StateGraph, START, END

class State(TypedDict):
    question: str
    evidence: str
    report: str

def search(s: State):
    return {"evidence": "  CPU high  "}
def clean(s: State):
    return {"evidence": s["evidence"].strip()}
def report(s: State):
    return {"report": s["question"] + ": " + s["evidence"]}

sub = StateGraph(State)
sub.add_node("search", search)
sub.add_node("clean", clean)
sub.add_edge(START, "search")
sub.add_edge("search", "clean")
sub.add_edge("clean", END)
b = StateGraph(State)
b.add_node("research", sub.compile())
b.add_node("report", report)
b.add_edge(START, "research")
b.add_edge("research", "report")
b.add_edge("report", END)
print(b.compile().invoke({"question": "原因"}))
