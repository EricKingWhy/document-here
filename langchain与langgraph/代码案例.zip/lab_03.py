from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_core.messages import AIMessage
from langchain_core.output_parsers import StrOutputParser

prompt = ChatPromptTemplate.from_template("总结告警：{alert}")
# 模拟模型，不花 API 费用
fake_model = RunnableLambda(lambda value: AIMessage(content="排查：" + value.to_string()))
chain = prompt | fake_model | StrOutputParser()
print(chain.invoke({"alert": "CPU 95%"}))
