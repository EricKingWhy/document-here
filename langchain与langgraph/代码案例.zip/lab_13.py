from typing import TypedDict
from langgraph.graph import StateGraph, START, END

class State(TypedDict):
    service: str
    cpu: int
    conclusion: str

def collect(state: State):
    return {"cpu": 95}

def diagnose(state: State):
    return {"conclusion": "CPU 高" if state["cpu"] >= 90 else "正常"}

builder = StateGraph(State)
builder.add_node("collect", collect)
builder.add_node("diagnose", diagnose)
builder.add_edge(START, "collect")
builder.add_edge("collect", "diagnose")
builder.add_edge("diagnose", END)
graph = builder.compile()
print(graph.invoke({"service": "order-api"}))
