from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

pages = [Document(page_content="CPU 高时先查看进程。\n内存高时检查堆使用。\n502 时检查上游服务。",
                  metadata={"source": "runbook.md", "page": 1})]
splitter = RecursiveCharacterTextSplitter(chunk_size=18, chunk_overlap=4,
                                          separators=["\n", "。", ""])
for doc in splitter.split_documents(pages):
    print(repr(doc.page_content), doc.metadata)
