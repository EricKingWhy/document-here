from langchain_core.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_messages([
    ("system", "你是运维助手。仅根据证据回答。"),
    ("human", "服务：{service}；告警：{alert}")
])
messages = prompt.format_messages(service="order-api", alert="CPU 95%")
for message in messages:
    print(message.type, message.content)
