from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.checkpoint.memory import InMemorySaver
from langchain_core.messages import AIMessage

def reply(state: MessagesState):
    humans = sum(m.type == "human" for m in state["messages"])
    return {"messages": [AIMessage(content=f"第 {humans} 次提问")]}

b = StateGraph(MessagesState)
b.add_node("reply", reply)
b.add_edge(START, "reply")
b.add_edge("reply", END)
g = b.compile(checkpointer=InMemorySaver())
cfg = {"configurable": {"thread_id": "ticket-001"}}
for text in ["CPU 高", "还有日志吗"]:
    r = g.invoke({"messages": [{"role": "user", "content": text}]}, cfg)
    print(r["messages"][-1].content)
print(len(g.get_state(cfg).values["messages"]))
