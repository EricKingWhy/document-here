# LangChain / LangGraph 复习实验

Python 3.11。示例以 1.x 公共 API 为基线；安装后记录实际版本。此环境无法取得 LangChain/LangGraph 依赖，全部示例通过 Python AST 语法检查，未执行框架集成或真实模型测试。

```bat
conda create -n agent-review python=3.11 -y
conda activate agent-review
python -m pip install -r requirements.txt
python -m pip freeze > requirements.lock.txt
python lab_02.py
```

需要 API 的示例：在 Windows Anaconda Prompt 设置 `set OPENAI_API_KEY=你的密钥`、`set LLM_MODEL=供应商实际支持的模型名`，如使用兼容服务再设置 `set OPENAI_BASE_URL=供应商文档指定的地址`。不需要访问模型的示例均标记本地。工具调用和结构化输出需要供应商相应支持。

SSE：在源码目录运行 `python -m uvicorn lab_27:app --host 127.0.0.1 --port 8000`，在 /docs 试接口（Swagger 不一定逐条渲染流）。另开终端：

```bash
curl -N -X POST http://127.0.0.1:8000/diagnose/stream -H 'Content-Type: application/json' -d '{"service":"order-api"}'
```

在 Windows PowerShell 可用 `Invoke-RestMethod -Uri http://127.0.0.1:8000/diagnose/stream -Method Post -ContentType 'application/json' -Body '{"service":"order-api"}'`（可能缓冲显示）。

## 文件对照
- lab_01.py — 模型调用与 Messages [API]
- lab_02.py — PromptTemplate 与变量填充 [本地]
- lab_03.py — LCEL 与 Runnable：链式调用 [本地]
- lab_04.py — invoke / batch / ainvoke / stream [本地]
- lab_05.py — 结构化输出 Pydantic [API]
- lab_06.py — @tool 与参数 Schema [本地]
- lab_07.py — bind_tools 与手动 Tool Calling [API]
- lab_08.py — create_agent：完整工具循环 [API]
- lab_09.py — Middleware：工具错误与调用策略 [API]
- lab_10.py — Document / metadata 与文本切块 [本地]
- lab_11.py — Embedding、向量库与 Retriever [本地]
- lab_12.py — 两阶段 RAG：检索→生成→引用 [API]
- lab_13.py — StateGraph / State / Node / Edge [本地]
- lab_14.py — Conditional Edge 条件路由 [本地]
- lab_15.py — Reducer、并行节点与汇合 [本地]
- lab_16.py — MessagesState 与 add_messages [本地]
- lab_17.py — 手写 ReAct 图：ToolNode + tools_condition [API]
- lab_18.py — Command：同时更新状态与跳转 [本地]
- lab_19.py — Send：动态并行任务 [本地]
- lab_20.py — Checkpointer / thread_id 与状态恢复 [本地]
- lab_21.py — interrupt / Command(resume)：人工审批 [本地]
- lab_22.py — RetryPolicy、超时与恢复边界 [本地]
- lab_23.py — 短期记忆与长期 Store [本地]
- lab_24.py — stream_mode=updates / values / custom [本地]
- lab_25.py — 异步节点与并发 I/O [本地]
- lab_26.py — Subgraph 与多 Agent 分工 [本地]
- lab_27.py — FastAPI + astream + SSE [本地服务]
- lab_28.py — 测试、Trace 与可观测性 [本地]
- lab_29.py — OnCall：智能运维诊断工作流 [本地]
- lab_30.py — DeepResearch：有界搜索与评审循环 [本地]
