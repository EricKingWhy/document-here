from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.types import RetryPolicy

class State(TypedDict):
    status: str
attempts = 0  # 仅教学故障注入，生产不要用全局计数共享请求

def fetch(state: State):
    global attempts
    attempts += 1
    if attempts == 1:
        raise TimeoutError("simulated transient failure")
    return {"status": "ok"}

b = StateGraph(State)
b.add_node("fetch", fetch, retry_policy=RetryPolicy(max_attempts=2,
    initial_interval=0.1, jitter=False, retry_on=TimeoutError))
b.add_edge(START, "fetch")
b.add_edge("fetch", END)
print(b.compile().invoke({}))
print("attempts:", attempts)
