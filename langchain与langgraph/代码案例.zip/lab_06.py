from langchain_core.tools import tool

@tool
def get_cpu(service: str) -> dict:
    """查询指定服务的 CPU 使用率，返回百分比（教学模拟）。"""
    data = {"order-api": 95, "payment-api": 40}
    if service not in data:
        return {"error": "unknown service"}
    return {"service": service, "cpu": data[service]}

print(get_cpu.name)
print(get_cpu.args)
print(get_cpu.invoke({"service": "order-api"}))
