from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_core.documents import Document

class DemoEmbeddings(Embeddings):
    words = ["CPU", "内存", "502"]
    def embed_query(self, text):
        return [float(text.count(word)) for word in self.words]
    def embed_documents(self, texts):
        return [self.embed_query(text) for text in texts]

store = InMemoryVectorStore(DemoEmbeddings())
store.add_documents([
    Document(page_content="CPU CPU 高：检查进程", metadata={"source": "cpu.md"}),
    Document(page_content="内存不足：检查堆", metadata={"source": "memory.md"}),
    Document(page_content="502：检查上游", metadata={"source": "http.md"})])
retriever = store.as_retriever(search_kwargs={"k": 1})
for doc in retriever.invoke("CPU 高怎么办？"):
    print(doc.page_content, doc.metadata)
