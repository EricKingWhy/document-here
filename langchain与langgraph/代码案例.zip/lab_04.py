import asyncio
from langchain_core.runnables import RunnableLambda

async def enrich(service: str) -> str:
    await asyncio.sleep(0.1)
    return f"{service}: OK"

sync_chain = RunnableLambda(lambda s: s.upper())
print(sync_chain.invoke("api"))
print(sync_chain.batch(["api", "db"], config={"max_concurrency": 2}))

async def main():
    chain = RunnableLambda(enrich)
    print(await chain.ainvoke("api"))
    print(await chain.abatch(["api", "db"]))

asyncio.run(main())
