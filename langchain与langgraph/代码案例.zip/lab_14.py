from typing import TypedDict, Literal
from langgraph.graph import StateGraph, START, END

class State(TypedDict):
    cpu: int
    result: str

def classify(state: State):
    return {}
def route(state: State) -> Literal["high", "low"]:
    return "high" if state["cpu"] >= 90 else "low"
def investigate(state: State):
    return {"result": "进入排查"}
def close(state: State):
    return {"result": "无需升级"}

b = StateGraph(State)
for name, fn in [("classify", classify), ("investigate", investigate), ("close", close)]:
    b.add_node(name, fn)
b.add_edge(START, "classify")
b.add_conditional_edges("classify", route, {"high": "investigate", "low": "close"})
b.add_edge("investigate", END)
b.add_edge("close", END)
g = b.compile()
print(g.invoke({"cpu": 95}))
print(g.invoke({"cpu": 40}))
