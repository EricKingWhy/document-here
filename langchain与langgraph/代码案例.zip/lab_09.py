import os
from langchain.agents import create_agent
from langchain.agents.middleware import wrap_tool_call
from langchain_core.messages import ToolMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

@tool
def query_service(service: str) -> str:
    """读取服务状态（教学模拟）。"""
    if service != "order-api":
        raise ValueError("unknown service")
    return "healthy"

@wrap_tool_call
def handle_error(request, handler):
    try:
        return handler(request)
    except ValueError:
        return ToolMessage(content="服务名无效，请核对后重试。",
                           tool_call_id=request.tool_call["id"])

agent = create_agent(ChatOpenAI(model=os.environ["LLM_MODEL"], timeout=30),
                     tools=[query_service], middleware=[handle_error])
print(agent.invoke({"messages": [{"role": "user", "content": "查 xyz 状态"}]},
                   config={"recursion_limit": 8})["messages"][-1].content)
