import os
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from langgraph.graph import StateGraph, MessagesState, START
from langgraph.prebuilt import ToolNode, tools_condition

@tool
def get_log(service: str) -> str:
    """查询服务最近错误日志（模拟）。"""
    return "upstream timeout" if service == "order-api" else "no data"

model = ChatOpenAI(model=os.environ["LLM_MODEL"], timeout=30).bind_tools([get_log])
def call_model(state: MessagesState):
    return {"messages": [model.invoke(state["messages"])]}

b = StateGraph(MessagesState)
b.add_node("model", call_model)
b.add_node("tools", ToolNode([get_log]))
b.add_edge(START, "model")
b.add_conditional_edges("model", tools_condition)
b.add_edge("tools", "model")
g = b.compile()
r = g.invoke({"messages": [{"role": "user", "content": "用日志分析 order-api"}]},
             config={"recursion_limit": 10})
print(r["messages"][-1].content)
