from typing import Literal
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
import os

class Triage(BaseModel):
    service: str
    severity: Literal["low", "high"]
    reason: str = Field(description="简短分类依据")

model = ChatOpenAI(model=os.environ["LLM_MODEL"], timeout=30)
classifier = model.with_structured_output(Triage)
result = classifier.invoke("order-api 错误率 30%，判断等级")
print(result.severity, result.service)
print(result.model_dump())
