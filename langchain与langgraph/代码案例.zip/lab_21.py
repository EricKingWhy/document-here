from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import interrupt, Command

class State(TypedDict):
    proposal: str
    result: str

def review(state: State):
    approved = interrupt({"proposal": state["proposal"]})
    return {"result": "审批通过，待执行" if approved is True else "拒绝"}

b = StateGraph(State)
b.add_node("review", review)
b.add_edge(START, "review")
b.add_edge("review", END)
g = b.compile(checkpointer=InMemorySaver())
cfg = {"configurable": {"thread_id": "approval-001"}}
paused = g.invoke({"proposal": "建议重启 order-api（演示，不执行）"}, cfg)
print(paused["__interrupt__"])
print(g.invoke(Command(resume=True), cfg)["result"])
