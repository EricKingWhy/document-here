from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage
import os

model = ChatOpenAI(model=os.environ["LLM_MODEL"], temperature=0, timeout=30)
messages = [SystemMessage(content="你是运维助手，只解释现象，不执行操作。"),
            HumanMessage(content="HTTP 502 常见原因是什么？")]
reply = model.invoke(messages)
print(reply.content)
print(reply.usage_metadata)
