import operator
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send

class State(TypedDict):
    queries: list[str]
    evidence: Annotated[list[str], operator.add]
class WorkerState(TypedDict):
    query: str

def dispatch(state: State):
    return [Send("search", {"query": q}) for q in state["queries"]]
def search(state: WorkerState):
    return {"evidence": ["模拟检索：" + state["query"]]}

b = StateGraph(State)
b.add_node("search", search)
b.add_conditional_edges(START, dispatch, ["search"])
b.add_edge("search", END)
print(b.compile().invoke({"queries": ["CPU", "日志", "发布记录"], "evidence": []}))
