import java.util.List;

public class Demo05 {
    public static void main(String[] args) {
        List<String> ids = List.of("O100", "O101", "O102");
        StringBuilder sb = new StringBuilder("失败订单: ");
        for (String id : ids) {
            sb.append(id).append(' ');
        }
        System.out.println(sb.toString().strip());
        System.out.println(String.join(",", ids));
        System.out.println("共 %d 条失败记录".formatted(ids.size()));
    }
}
