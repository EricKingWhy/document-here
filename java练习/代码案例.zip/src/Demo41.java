import java.util.Map;
import java.util.Optional;

public class Demo41 {
    public static void main(String[] args) {
        Map<Long, String> names = Map.of(1L, "Alice");
        Optional<String> found = Optional.ofNullable(names.get(1L));
        System.out.println(found.map(String::toUpperCase).orElse("未知"));
        System.out.println(Optional.ofNullable(names.get(99L)).orElseGet(() -> "未知"));
        try { Optional.ofNullable(names.get(99L)).orElseThrow(() -> new IllegalArgumentException("用户不存在")); }
        catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
    }
}
