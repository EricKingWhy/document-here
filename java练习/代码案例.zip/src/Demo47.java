import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;

public class Demo47 {
    public static void main(String[] args) throws Exception {
        Path path = Files.createTempFile("demo-orders-", ".txt");
        try {
            Files.writeString(path, "O1,PAID\nO2,NEW", StandardCharsets.UTF_8);
            String text = Files.readString(path, StandardCharsets.UTF_8);
            System.out.println(text);
            System.out.println(Files.exists(path));
        } finally {
            Files.deleteIfExists(path);
        }
    }
}
