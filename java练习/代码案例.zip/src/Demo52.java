public class Demo52 {
    public static void main(String[] args) throws Exception {
        Runnable task = () -> System.out.println("执行线程: " + Thread.currentThread().getName());
        Thread a = new Thread(task, "worker-A");
        Thread b = new Thread(task, "worker-B");
        a.start(); b.start();
        a.join(); b.join();
        System.out.println("汇总完成");
    }
}
