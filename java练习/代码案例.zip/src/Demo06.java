import java.util.Arrays;

public class Demo06 {
    public static void main(String[] args) {
        int[] ids = {101, 102, 103, 104};
        ids[1] = 999;
        System.out.println(ids[0]);
        System.out.println(Arrays.toString(ids));
        int[] expanded = Arrays.copyOf(ids, 5);
        System.out.println(Arrays.toString(expanded));
    }
}
