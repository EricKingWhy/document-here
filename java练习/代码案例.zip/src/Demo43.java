public class Demo43 {
    public static void main(String[] args) {
        try {
            reserve(2, 5);
        } catch (BusinessException e) {
            System.out.println(e.code + ":" + e.getMessage());
        }
    }

    static void reserve(int stock, int qty) {
        if (qty <= 0) throw new BusinessException("INVALID_QUANTITY", "数量非法");
        if (stock < qty) throw new BusinessException("NO_STOCK", "库存不足");
        System.out.println("预留成功");
    }
    static class BusinessException extends RuntimeException {
        final String code;
        BusinessException(String code, String message) { super(message); this.code = code; }
    }
}
