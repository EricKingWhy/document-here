public class Demo15 {
    public static void main(String[] args) {
        Product product = new Product(10);
        product.setStock(8);
        System.out.println(product.getStock());
        try { product.setStock(-1); }
        catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
        System.out.println(product.getStock());
    }

    static class Product {
        private int stock;
        Product(int stock) { setStock(stock); }
        public int getStock() { return stock; }
        public void setStock(int stock) {
            if (stock < 0) throw new IllegalArgumentException("库存不能为负数");
            this.stock = stock;
        }
    }
}
