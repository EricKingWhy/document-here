public class Demo14 {
    public static void main(String[] args) {
        User u1 = new User(1L, "Alice");
        User u2 = new User(2L, "Bob");
        System.out.println(u1.getDisplayName());
        System.out.println(u2.getDisplayName());
    }

    static class User {
        long id;
        String name;
        User(long id, String name) {
            this.id = id;
            this.name = name;
        }
        String getDisplayName() { return id + ":" + name; }
    }
}
