import java.util.List;
import java.util.ArrayList;

public class Demo26 {
    public static void main(String[] args) {
        List<String> ids = new ArrayList<>();
        ids.add("O100"); ids.add("O101"); ids.add("O102");
        System.out.println(ids.get(1));
        ids.set(1, "O201");
        ids.remove("O100");
        System.out.println(ids);
        System.out.println(ids.size());
        System.out.println(ids.contains("O102"));
        List<Integer> numbers = new ArrayList<>(List.of(1, 2, 3));
        numbers.remove(Integer.valueOf(1));
        System.out.println(numbers);
    }
}
