public class Demo42 {
    public static void main(String[] args) {
        String raw = "abc";
        int pageSize = 20;
        try {
            pageSize = Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            System.out.println("非法分页参数，使用默认值");
        } finally {
            System.out.println("参数解析结束");
        }
        System.out.println(pageSize);
    }
}
