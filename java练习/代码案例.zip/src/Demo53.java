import java.util.concurrent.atomic.AtomicInteger;

public class Demo53 {
    public static void main(String[] args) throws Exception {
        AtomicInteger count = new AtomicInteger();
        Runnable work = () -> { for (int i = 0; i < 1000; i++) count.incrementAndGet(); };
        Thread a = new Thread(work), b = new Thread(work);
        a.start(); b.start(); a.join(); b.join();
        System.out.println(count.get());
        Counter counter = new Counter(); counter.increment();
        System.out.println(counter.get());
    }

    static class Counter {
        private int value;
        synchronized void increment() { value++; }
        synchronized int get() { return value; }
    }
}
