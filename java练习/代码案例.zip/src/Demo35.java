import java.util.List;

public class Demo35 {
    public static void main(String[] args) {
        ApiResult<String> result = new ApiResult<>(200, "success");
        System.out.println(result.data());
        System.out.println(first(List.of(10, 20, 30)));
        System.out.println(first(List.of("O1", "O2")));
    }

    record ApiResult<T>(int code, T data) {}
    static <T> T first(List<T> list) {
        if (list.isEmpty()) throw new IllegalArgumentException("空列表");
        return list.get(0);
    }
}
