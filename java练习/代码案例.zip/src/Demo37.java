import java.util.function.Predicate;
import java.util.function.Function;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Demo37 {
    public static void main(String[] args) {
        Predicate<Integer> enough = price -> price >= 100;
        System.out.println(enough.test(120));
        Function<String, String> normalize = String::toUpperCase;
        System.out.println(normalize.apply("paid"));
        Consumer<String> log = msg -> System.out.println("INFO " + msg);
        log.accept("开始执行");
        Supplier<String> defaultStatus = () -> "NEW";
        System.out.println(defaultStatus.get());
    }
}
