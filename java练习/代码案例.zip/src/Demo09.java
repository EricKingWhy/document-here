public class Demo09 {
    public static void main(String[] args) {
        int[] quantities = {2, 5, 3};
        for (int i = 0; i < quantities.length; i++) {
            System.out.println("第" + (i + 1) + "条: " + quantities[i]);
        }
        int total = 0;
        for (int qty : quantities) {
            total += qty;
        }
        System.out.println("总数量=" + total);
    }
}
