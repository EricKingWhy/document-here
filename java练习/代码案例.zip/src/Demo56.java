import java.util.concurrent.ConcurrentHashMap;

public class Demo56 {
    public static void main(String[] args) throws Exception {
        ConcurrentHashMap<String, Integer> counts = new ConcurrentHashMap<>();
        Runnable work = () -> { for (int i = 0; i < 100; i++) counts.merge("ERROR", 1, Integer::sum); };
        Thread a = new Thread(work), b = new Thread(work);
        a.start(); b.start(); a.join(); b.join();
        System.out.println(counts.get("ERROR"));
    }
}
