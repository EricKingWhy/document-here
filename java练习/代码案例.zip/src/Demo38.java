import java.util.List;
import java.util.ArrayList;

public class Demo38 {
    public static void main(String[] args) {
        List<Order> orders = List.of(new Order("O1", "PAID"), new Order("O2", "NEW"), new Order("O3", "PAID"));
        List<String> oldStyle = new ArrayList<>();
        for (Order order : orders) {
            if ("PAID".equals(order.status())) oldStyle.add(order.id());
        }
        List<String> ids = orders.stream()
                .filter(order -> "PAID".equals(order.status()))
                .map(Order::id)
                .toList();
        System.out.println(oldStyle);
        System.out.println(ids);
    }

    record Order(String id, String status) {}
}
