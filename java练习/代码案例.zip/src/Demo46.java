import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;

public class Demo46 {
    public static void main(String[] args) {
        System.out.println(Objects.equals(null, null));
        System.out.println(Objects.requireNonNullElse(null, "默认值"));
        int pageSize = Math.min(Math.max(200, 1), 100);
        System.out.println(pageSize);
        Pattern p = Pattern.compile("O[0-9]{3,6}");
        System.out.println(p.matcher("O1234").matches());
        System.out.println(UUID.randomUUID().toString().length());
    }
}
