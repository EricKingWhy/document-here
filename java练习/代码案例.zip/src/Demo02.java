public class Demo02 {
    public static void main(String[] args) {
        long orderId = 100001L;
        int quantity = 3;
        boolean paid = true;
        String status = "PAID";
        Integer pageSize = null;
        int actualSize = pageSize == null ? 20 : pageSize;
        System.out.println(orderId + " " + quantity + " " + paid + " " + status);
        System.out.println("分页大小=" + actualSize);
    }
}
