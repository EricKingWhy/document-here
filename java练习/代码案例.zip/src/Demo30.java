import java.util.Map;
import java.util.HashMap;

public class Demo30 {
    public static void main(String[] args) {
        Map<Long, String> users = new HashMap<>();
        users.put(101L, "Alice"); users.put(102L, "Bob");
        System.out.println(users.get(101L));
        System.out.println(users.put(102L, "Robert"));
        System.out.println(users.get(102L));
        System.out.println(users.getOrDefault(999L, "未知用户"));
        users.put(103L, null);
        System.out.println(users.containsKey(103L));
        users.remove(101L);
        System.out.println(users.size());
    }
}
