import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

public class Demo48 {
    public static void main(String[] args) throws Exception {
        byte[] bytes = "INFO 启动\nERROR 超时\nINFO 完成".getBytes(StandardCharsets.UTF_8);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(bytes), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("ERROR")) System.out.println(line);
            }
        }
    }
}
