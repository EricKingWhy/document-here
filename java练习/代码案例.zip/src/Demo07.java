public class Demo07 {
    public static void main(String[] args) {
        int quantity = 2, stock = 5;
        String result;
        if (quantity <= 0) {
            result = "数量非法";
        } else if (quantity > stock) {
            result = "库存不足";
        } else {
            result = "允许下单";
        }
        String label = stock > 0 ? "有货" : "售罄";
        System.out.println(result + " / " + label);
    }
}
