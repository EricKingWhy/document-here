import java.util.List;

public class Demo49 {
    public static void main(String[] args) {
        java.util.List<String> ids = java.util.List.of("O1", "O2");
        List<String> imported = List.of("O3");
        System.out.println(ids);
        System.out.println(imported);
        System.out.println(MainPlaceholder.class.getSimpleName());
    }

    static class MainPlaceholder {}
}
