import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;

public class Demo31 {
    public static void main(String[] args) {
        List<String> levels = List.of("INFO", "ERROR", "INFO");
        Map<String, Integer> counts = new HashMap<>();
        for (String level : levels) counts.merge(level, 1, Integer::sum);
        for (Map.Entry<String, Integer> e : new TreeMap<>(counts).entrySet()) {
            System.out.println(e.getKey() + "=" + e.getValue());
        }
        Map<String, List<String>> grouped = new HashMap<>();
        grouped.computeIfAbsent("order", key -> new ArrayList<>()).add("CPU");
        grouped.computeIfAbsent("order", key -> new ArrayList<>()).add("TIMEOUT");
        System.out.println(grouped.get("order"));
    }
}
