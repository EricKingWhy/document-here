import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.Duration;
import java.time.format.DateTimeFormatter;

public class Demo45 {
    public static void main(String[] args) {
        Instant created = Instant.parse("2026-01-01T00:00:00Z");
        ZonedDateTime local = created.atZone(ZoneId.of("Asia/Shanghai"));
        System.out.println(local.format(DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm")));
        LocalDate due = local.toLocalDate().plusDays(7);
        System.out.println(due);
        System.out.println(Duration.between(created, created.plusSeconds(1800)).toMinutes());
    }
}
