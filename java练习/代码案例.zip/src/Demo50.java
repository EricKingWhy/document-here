import java.lang.reflect.Method;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

public class Demo50 {
    public static void main(String[] args) throws Exception {
        Method method = OrderService.class.getDeclaredMethod("cancel");
        Audit audit = method.getAnnotation(Audit.class);
        System.out.println(method.getName());
        System.out.println(audit.value());
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface Audit { String value(); }
    static class OrderService {
        @Audit("取消订单") public void cancel() {}
    }
}
