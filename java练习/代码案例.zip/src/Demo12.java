public class Demo12 {
    public static void main(String[] args) {
        log("service ready");
        log("WARN", "timeout");
        System.out.println(sum(2, 3, 5));
    }

    static void log(String message) { log("INFO", message); }
    static void log(String level, String message) {
        System.out.println(level + " " + message);
    }
    static int sum(int... values) {
        int result = 0;
        for (int v : values) result += v;
        return result;
    }
}
