import java.util.List;

public class Demo39 {
    public static void main(String[] args) {
        List<Integer> ids = List.of(5, 3, 3, 2, 1, 4);
        System.out.println(ids.stream().distinct().sorted().skip(2).limit(2).toList());
        List<Integer> quantities = List.of(2, 3, 5);
        System.out.println(quantities.stream().mapToInt(Integer::intValue).sum());
        System.out.println(quantities.stream().mapToInt(Integer::intValue).max().orElse(0));
        System.out.println(quantities.stream().anyMatch(n -> n < 3));
    }
}
