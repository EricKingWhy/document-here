import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

public class Demo34 {
    public static void main(String[] args) {
        List<String> ids = new ArrayList<>(List.of("O1", "", "TEST-1", "O2"));
        Iterator<String> it = ids.iterator();
        while (it.hasNext()) {
            String id = it.next();
            if (id.isBlank()) it.remove();
        }
        ids.removeIf(id -> id.startsWith("TEST"));
        System.out.println(ids);
        List<String> readOnly = List.copyOf(ids);
        System.out.println(readOnly);
    }
}
