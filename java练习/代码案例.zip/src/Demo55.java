import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CompletableFuture;

public class Demo55 {
    public static void main(String[] args) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        try {
            CompletableFuture<String> metrics = CompletableFuture.supplyAsync(() -> "CPU=80%", pool);
            CompletableFuture<String> alerts = CompletableFuture.supplyAsync(() -> "告警=2", pool);
            String result = metrics.thenCombine(alerts, (m, a) -> m + ", " + a)
                    .orTimeout(2, TimeUnit.SECONDS).join();
            System.out.println(result);
        } finally {
            pool.shutdown();
        }
    }
}
