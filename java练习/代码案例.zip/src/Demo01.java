public class Demo01 {
    public static void main(String[] args) {
        String serviceName = "order-service";
        System.out.println("启动服务: " + serviceName);
        System.out.println("参数个数: " + args.length);
    }
}
