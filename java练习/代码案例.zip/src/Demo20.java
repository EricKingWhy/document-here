public class Demo20 {
    public static void main(String[] args) {
        OrderService service = new OrderService(new EmailNotifier());
        service.finish("O100");
        new OrderService(new SmsNotifier()).finish("O101");
    }

    interface Notifier { void send(String message); }
    static class EmailNotifier implements Notifier {
        public void send(String message) { System.out.println("邮件: " + message); }
    }
    static class SmsNotifier implements Notifier {
        public void send(String message) { System.out.println("短信: " + message); }
    }
    static class OrderService {
        private final Notifier notifier;
        OrderService(Notifier notifier) { this.notifier = notifier; }
        void finish(String id) { notifier.send(id + " 已完成"); }
    }
}
