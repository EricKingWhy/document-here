public class Demo08 {
    public static void main(String[] args) {
        String status = "PAID";
        String label = switch (status) {
            case "NEW" -> "待支付";
            case "PAID" -> "待发货";
            case "DONE" -> "已完成";
            default -> "未知状态";
        };
        System.out.println(label);
        // 老代码中的传统写法
        switch (status) {
            case "PAID": System.out.println("发送发货提醒"); break;
            default: System.out.println("无需提醒");
        }
    }
}
