public class Demo17 {
    public static void main(String[] args) {
        AlertTask task = new AlertTask("CPU告警");
        task.run();
    }

    static class BaseTask {
        private final String name;
        BaseTask(String name) { this.name = name; }
        void run() { System.out.println("开始任务: " + name); }
    }
    static class AlertTask extends BaseTask {
        AlertTask(String name) { super(name); }
        @Override void run() {
            super.run();
            System.out.println("发送告警");
        }
    }
}
