import java.util.List;

public class Demo10 {
    public static void main(String[] args) {
        int attempt = 0;
        while (attempt < 3) {
            attempt++;
            boolean ok = attempt == 3;
            System.out.println("第" + attempt + "次: " + ok);
            if (ok) break;
        }
        for (String id : List.of("O1", "", "O2")) {
            if (id.isBlank()) continue;
            System.out.println("处理 " + id);
        }
    }
}
