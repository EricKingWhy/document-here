import java.util.List;
import java.util.ArrayList;

public class Demo13 {
    public static void main(String[] args) {
        int count = 1;
        List<String> names = new ArrayList<>(List.of("Alice"));
        changeNumber(count);
        changeList(names);
        System.out.println(count);
        System.out.println(names);
    }

    static void changeNumber(int n) { n = 99; }
    static void changeList(List<String> list) {
        list.add("Bob");
        list = new ArrayList<>(List.of("Carol"));
    }
}
