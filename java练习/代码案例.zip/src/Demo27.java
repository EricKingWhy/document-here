import java.util.List;
import java.util.ArrayList;

public class Demo27 {
    public static void main(String[] args) {
        List<Order> orders = List.of(new Order("O1", "PAID", 3),
                new Order("O2", "NEW", 2), new Order("O3", "PAID", 0));
        List<Order> ready = new ArrayList<>();
        for (Order order : orders) {
            if ("PAID".equals(order.status()) && order.quantity() > 0) ready.add(order);
        }
        System.out.println(ready);
        Order found = findById(orders, "O2");
        System.out.println(found == null ? "未找到" : found.status());
    }

    record Order(String id, String status, int quantity) {}
    static Order findById(List<Order> orders, String id) {
        for (Order order : orders) {
            if (order.id().equals(id)) return order;
        }
        return null;
    }
}
