import java.util.List;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;
import java.util.Set;

public class Demo29 {
    public static void main(String[] args) {
        List<Long> ids = List.of(1L, 2L, 1L, 3L);
        Set<Long> unique = new LinkedHashSet<>(ids);
        System.out.println(unique);
        Set<String> permissions = new HashSet<>(List.of("order:read", "order:write"));
        System.out.println(permissions.contains("order:write"));
        System.out.println(permissions.add("order:read"));
        System.out.println(new TreeSet<>(List.of(3, 1, 2)));
    }
}
