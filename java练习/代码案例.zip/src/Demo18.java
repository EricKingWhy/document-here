import java.util.List;

public class Demo18 {
    public static void main(String[] args) {
        List<Payment> channels = List.of(new CardPayment(), new BalancePayment());
        for (Payment channel : channels) {
            channel.pay(100);
        }
    }

    static class Payment {
        void pay(int cents) { System.out.println("通用支付"); }
    }
    static class CardPayment extends Payment {
        @Override void pay(int cents) { System.out.println("银行卡: " + cents); }
    }
    static class BalancePayment extends Payment {
        @Override void pay(int cents) { System.out.println("余额: " + cents); }
    }
}
