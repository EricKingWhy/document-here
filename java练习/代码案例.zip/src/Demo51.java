import java.util.logging.Logger;
import java.util.logging.Level;

public class Demo51 {
    public static void main(String[] args) {
        Logger log = Logger.getLogger("order-demo");
        try {
            validate(0);
        } catch (IllegalArgumentException e) {
            log.log(Level.WARNING, "requestId=req-001 订单校验失败", e);
        }
        System.out.println("请求处理结束");
    }

    static void validate(int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("quantity 必须大于 0");
    }
}
