public class Demo03 {
    public static void main(String[] args) {
        int stock = 8, quantity = 3;
        boolean canOrder = quantity > 0 && stock >= quantity;
        String remark = null;
        boolean hasRemark = remark != null && !remark.isBlank();
        System.out.println(canOrder);
        System.out.println(hasRemark);
        System.out.println(3 / 2);
        System.out.println((double) 3 / 2);
    }
}
