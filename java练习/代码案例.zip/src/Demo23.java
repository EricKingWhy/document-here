public class Demo23 {
    public static void main(String[] args) {
        OrderStatus status = OrderStatus.PAID;
        System.out.println(status.label);
        System.out.println(status == OrderStatus.PAID);
        System.out.println(OrderStatus.valueOf("NEW").label);
    }

    enum OrderStatus {
        NEW("待支付"), PAID("已支付"), SHIPPED("已发货"), DONE("已完成");
        final String label;
        OrderStatus(String label) { this.label = label; }
    }
}
