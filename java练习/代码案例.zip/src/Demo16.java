import java.util.List;
import java.util.ArrayList;

public class Demo16 {
    public static void main(String[] args) {
        new Client();
        new Client();
        System.out.println(Client.created);
        System.out.println(Math.min(200, Client.MAX_PAGE_SIZE));
        final List<String> items = new ArrayList<>();
        items.add("O1");
        System.out.println(items);
    }

    static class Client {
        static final int MAX_PAGE_SIZE = 100;
        static int created = 0;
        Client() { created++; }
    }
}
