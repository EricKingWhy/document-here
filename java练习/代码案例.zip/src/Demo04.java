public class Demo04 {
    public static void main(String[] args) {
        String raw = "  Alice  ";
        String name = raw.strip();
        String status = new String("PAID");
        System.out.println(name + ":" + name.length());
        System.out.println("PAID".equals(status));
        System.out.println("user,order,admin".split(",")[1]);
        System.out.println("order-service".startsWith("order"));
        System.out.println("   ".isBlank());
    }
}
