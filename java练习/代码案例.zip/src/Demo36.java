import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

public class Demo36 {
    public static void main(String[] args) {
        System.out.println(sum(List.of(1, 2, 3)));
        List<Number> out = new ArrayList<>();
        append(out);
        System.out.println(out);
        List<Order> orders = new ArrayList<>(List.of(new Order("O2", 10), new Order("O1", 10), new Order("O3", 20)));
        orders.sort(Comparator.comparingInt(Order::price).reversed().thenComparing(Order::id));
        System.out.println(orders);
    }

    record Order(String id, int price) {}
    static double sum(List<? extends Number> values) {
        double total = 0;
        for (Number value : values) total += value.doubleValue();
        return total;
    }
    static void append(List<? super Integer> values) { values.add(7); }
}
