import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class Demo54 {
    public static void main(String[] args) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        try {
            Future<Integer> users = pool.submit(() -> 12);
            Future<Integer> orders = pool.submit(() -> 30);
            System.out.println("用户=" + users.get(1, TimeUnit.SECONDS));
            System.out.println("订单=" + orders.get(1, TimeUnit.SECONDS));
        } finally {
            pool.shutdown();
        }
    }
}
