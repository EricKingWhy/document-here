public class Demo19 {
    public static void main(String[] args) {
        Task task = new ReportTask();
        task.execute();
    }

    static abstract class Task {
        final void execute() {
            System.out.println("开始");
            doWork();
            System.out.println("结束");
        }
        abstract void doWork();
    }
    static class ReportTask extends Task {
        @Override void doWork() { System.out.println("生成报告"); }
    }
}
