import java.util.List;
import java.util.HashSet;
import java.util.Set;

public class Demo22 {
    public static void main(String[] args) {
        UserKey a = new UserKey(1L);
        UserKey b = new UserKey(1L);
        System.out.println(a == b);
        System.out.println(a.equals(b));
        Set<UserKey> set = new HashSet<>(List.of(a, b));
        System.out.println(set.size());
        System.out.println(a);
    }

    static final class UserKey {
        private final long id;
        UserKey(long id) { this.id = id; }
        @Override public boolean equals(Object obj) {
            return obj instanceof UserKey other && id == other.id;
        }
        @Override public int hashCode() { return Long.hashCode(id); }
        @Override public String toString() { return "UserKey{id=" + id + "}"; }
    }
}
