import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Demo40 {
    public static void main(String[] args) {
        List<Order> orders = List.of(new Order("O1", "PAID"), new Order("O2", "NEW"), new Order("O3", "PAID"));
        Map<String, List<Order>> groups = orders.stream().collect(Collectors.groupingBy(Order::status));
        System.out.println(groups.get("PAID"));
        Map<String, Order> index = orders.stream().collect(Collectors.toMap(Order::id, Function.identity(), (a, b) -> a));
        System.out.println(index.get("O2"));
        System.out.println(orders.stream().map(Order::id).collect(Collectors.joining(",")));
    }

    record Order(String id, String status) {}
}
