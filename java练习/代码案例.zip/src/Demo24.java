public class Demo24 {
    public static void main(String[] args) {
        CreateUserRequest req = new CreateUserRequest("Alice");
        User user = new User(1L, req.name(), "hidden-hash");
        UserResponse response = new UserResponse(user.id(), user.name());
        System.out.println(response);
    }

    record CreateUserRequest(String name) {}
    record User(long id, String name, String passwordHash) {}
    record UserResponse(long id, String name) {}
}
