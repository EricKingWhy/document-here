public class Demo11 {
    public static void main(String[] args) {
        System.out.println(canOrder(2, 5));
        System.out.println(canOrder(0, 5));
        System.out.println(canOrder(6, 5));
    }

    static boolean canOrder(int quantity, int stock) {
        if (quantity <= 0) return false;
        return quantity <= stock;
    }
}
