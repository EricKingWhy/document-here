import java.util.Map;

public class Demo21 {
    public static void main(String[] args) {
        OrderService service = new OrderService(new MemoryRepository());
        System.out.println(service.describe("O1"));
        System.out.println(service.describe("O9"));
    }

    interface Repository { String findStatus(String id); }
    static class MemoryRepository implements Repository {
        private final Map<String, String> data = Map.of("O1", "PAID");
        public String findStatus(String id) { return data.get(id); }
    }
    static class OrderService {
        private final Repository repository;
        OrderService(Repository repository) { this.repository = repository; }
        String describe(String id) {
            String status = repository.findStatus(id);
            return status == null ? "订单不存在" : id + ":" + status;
        }
    }
}
