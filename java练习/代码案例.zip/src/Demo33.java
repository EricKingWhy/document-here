import java.util.Map;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class Demo33 {
    public static void main(String[] args) {
        Map<String, String> labels = new LinkedHashMap<>();
        labels.put("NEW", "待支付"); labels.put("DONE", "完成"); labels.put("PAID", "已支付");
        System.out.println(labels.keySet());
        TreeMap<String, String> sorted = new TreeMap<>(labels);
        System.out.println(sorted.keySet());
        System.out.println(sorted.firstKey());
    }
}
