import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.LinkedHashMap;

public class Demo58 {
    public static void main(String[] args) {
        OrderService service = new OrderService(new MemoryRepository());
        service.create("O1", 2);
        service.create("O2", 3);
        service.cancel("O1");
        System.out.println(service.list(Status.NEW));
        System.out.println(service.list(Status.CANCELLED));
        try { service.cancel("O1"); }
        catch (IllegalStateException e) { System.out.println(e.getMessage()); }
    }

    enum Status { NEW, CANCELLED }
    record Order(String id, int quantity, Status status) {}
    record OrderView(String id, int quantity, String status) {}
    interface OrderRepository {
        Order find(String id);
        void save(Order order);
        List<Order> findAll();
    }
    static class MemoryRepository implements OrderRepository {
        private final Map<String, Order> data = new LinkedHashMap<>();
        public Order find(String id) { return data.get(id); }
        public void save(Order order) { data.put(order.id(), order); }
        public List<Order> findAll() { return new ArrayList<>(data.values()); }
    }
    static class OrderService {
        private final OrderRepository repo;
        OrderService(OrderRepository repo) { this.repo = repo; }
        void create(String id, int quantity) {
            if (id == null || id.isBlank() || quantity <= 0) throw new IllegalArgumentException("参数非法");
            if (repo.find(id) != null) throw new IllegalArgumentException("订单已存在");
            repo.save(new Order(id, quantity, Status.NEW));
        }
        void cancel(String id) {
            Order order = repo.find(id);
            if (order == null) throw new IllegalArgumentException("订单不存在");
            if (order.status() != Status.NEW) throw new IllegalStateException("当前状态不可取消");
            repo.save(new Order(order.id(), order.quantity(), Status.CANCELLED));
        }
        List<OrderView> list(Status status) {
            return repo.findAll().stream().filter(o -> o.status() == status)
                .map(o -> new OrderView(o.id(), o.quantity(), o.status().name())).toList();
        }
    }
}
