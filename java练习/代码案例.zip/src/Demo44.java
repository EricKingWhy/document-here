import java.math.BigDecimal;
import java.math.RoundingMode;

public class Demo44 {
    public static void main(String[] args) {
        BigDecimal unit = new BigDecimal("19.99");
        BigDecimal total = unit.multiply(BigDecimal.valueOf(3));
        BigDecimal paid = total.multiply(new BigDecimal("0.90")).setScale(2, RoundingMode.HALF_UP);
        System.out.println(total);
        System.out.println(paid);
        System.out.println(new BigDecimal("1.0").compareTo(new BigDecimal("1.00")) == 0);
        System.out.println(new BigDecimal("1.0").equals(new BigDecimal("1.00")));
    }
}
