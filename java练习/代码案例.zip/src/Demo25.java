import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Queue;
import java.util.ArrayDeque;

public class Demo25 {
    public static void main(String[] args) {
        List<String> ids = List.of("O1", "O2", "O1");
        Set<String> unique = new HashSet<>(ids);
        Map<String, Integer> counts = new HashMap<>();
        for (String id : ids) counts.merge(id, 1, Integer::sum);
        Queue<String> queue = new ArrayDeque<>(ids);
        System.out.println(ids);
        System.out.println(unique.size());
        System.out.println(counts.get("O1"));
        System.out.println(queue.poll());
    }
}
