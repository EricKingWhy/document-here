import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class Demo32 {
    public static void main(String[] args) {
        List<User> users = List.of(new User(1L, "Alice"), new User(2L, "Bob"));
        List<Order> orders = List.of(new Order("O1", 2L), new Order("O2", 1L), new Order("O3", 9L));
        Map<Long, User> index = new HashMap<>();
        for (User user : users) index.put(user.id(), user);
        for (Order order : orders) {
            User user = index.get(order.userId());
            String name = user == null ? "未知用户" : user.name();
            System.out.println(order.id() + " -> " + name);
        }
    }

    record User(long id, String name) {}
    record Order(String id, long userId) {}
}
