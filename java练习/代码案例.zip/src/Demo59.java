public class Demo59 {
    public static void main(String[] args) {
        check(normalizeSize(20) == 20, "正常分页");
        check(normalizeSize(100) == 100, "边界分页");
        check(normalizeSize(101) == 100, "最大分页");
        boolean rejected = false;
        try { normalizeSize(0); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected, "拒绝非法分页");
        System.out.println("4 项验证通过");
    }

    static int normalizeSize(int size) {
        if (size <= 0) throw new IllegalArgumentException("size 必须大于 0");
        return Math.min(size, 100);
    }
    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
