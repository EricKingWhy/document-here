import java.util.Queue;
import java.util.Deque;
import java.util.ArrayDeque;

public class Demo28 {
    public static void main(String[] args) {
        Queue<String> tasks = new ArrayDeque<>();
        tasks.offer("T1"); tasks.offer("T2");
        System.out.println(tasks.peek());
        System.out.println(tasks.poll());
        System.out.println(tasks.poll());
        System.out.println(tasks.poll());
        Deque<String> urgent = new ArrayDeque<>();
        urgent.addLast("普通"); urgent.addFirst("紧急");
        System.out.println(urgent.removeFirst());
    }
}
